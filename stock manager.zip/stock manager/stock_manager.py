import csv
import os

# === CONFIGURATION ===

CATEGORIES = ("food", "technology", "electronics", "clothing")
CSV_FILE = "products.csv"

# === RUNTIME LISTS ===

products = []  # All products in memory


# === CORE FUNCTIONS ===

def load_products():
    """
    Load products from CSV file if it exists.
    """
    if not os.path.exists(CSV_FILE):
        return

    with open(CSV_FILE, mode='r', newline='', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        for row in reader:
            # Ensure correct types
            product = {
                "name": row["name"],
                "price": float(row["price"]),
                "stock": int(row["stock"]),
                "category": row["category"]
            }
            products.append(product)


def save_products():
    """
    Save all products to CSV file.
    """
    with open(CSV_FILE, mode='w', newline='', encoding='utf-8') as file:
        fieldnames = ["name", "price", "stock", "category"]
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        for product in products:
            writer.writerow(product)


def add_product():
    """
    Add a new product with unique name in its category.
    """
    print(f"Available categories: {CATEGORIES}")
    category = input("Select category: ").lower()
    if category not in CATEGORIES:
        print("Invalid category.")
        return

    name = input("Product name: ").strip()
    price = float(input("Price: "))
    stock = int(input("Stock amount: "))

    # Check for duplicate name in same category
    if any(p['name'] == name and p['category'] == category for p in products):
        print("This product already exists in the selected category.")
        return

    product = {"name": name, "price": price, "stock": stock, "category": category}
    products.append(product)
    save_products()
    print(f"{name} added successfully.")


def delete_product():
    """
    Delete a product by name and category.
    """
    category = input(f"Category to delete from {CATEGORIES}: ").lower()
    if category not in CATEGORIES:
        print("Invalid category.")
        return

    name = input("Product name to delete: ").strip()

    found = False
    for product in products:
        if product['name'] == name and product['category'] == category:
            products.remove(product)
            found = True
            save_products()
            print(f"{name} deleted successfully.")
            break

    if not found:
        print("Product not found.")


def list_products():
    """
    List all products in a specific category or all.
    """
    choice = input(f"Which category to list? {CATEGORIES} or 'all': ").lower()
    if choice == "all":
        selected = products
    elif choice in CATEGORIES:
        selected = [p for p in products if p['category'] == choice]
    else:
        print("Invalid choice.")
        return

    if not selected:
        print("No products to show.")
    else:
        for i, p in enumerate(selected, start=1):
            print(f"{i}. Name: {p['name']}, Price: ${p['price']:.2f}, Stock: {p['stock']}, Category: {p['category']}")


def update_price():
    """
    Update price of an existing product.
    """
    category = input(f"Category: {CATEGORIES}: ").lower()
    if category not in CATEGORIES:
        print("Invalid category.")
        return

    name = input("Product name: ").strip()
    found = False

    for product in products:
        if product['name'] == name and product['category'] == category:
            print(f"Current price: ${product['price']:.2f}")
            new_price = float(input("New price: "))
            product['price'] = new_price
            save_products()
            print("Price updated successfully.")
            found = True
            break

    if not found:
        print("Product not found.")


def update_stock():
    """
    Update stock of an existing product.
    """
    category = input(f"Category: {CATEGORIES}: ").lower()
    if category not in CATEGORIES:
        print("Invalid category.")
        return

    name = input("Product name: ").strip()
    found = False

    for product in products:
        if product['name'] == name and product['category'] == category:
            print(f"Current stock: {product['stock']}")
            new_stock = int(input("New stock amount: "))
            product['stock'] = new_stock
            save_products()
            print("Stock updated successfully.")
            found = True
            break

    if not found:
        print("Product not found.")


def report():
    """
    Show basic report: unique product count & total stock.
    """
    unique_names = set(p['name'] for p in products)
    total_stock = sum(p['stock'] for p in products)

    print(f"Unique product count: {len(unique_names)}")
    print(f"Total stock count: {total_stock}")

    # Optional: category breakdown
    print("\nStock by category:")
    for cat in CATEGORIES:
        cat_products = [p for p in products if p['category'] == cat]
        print(f"{cat.capitalize()}: {len(cat_products)} products")


# === MAIN MENU ===

def main():
    load_products()
    while True:
        print("\n1. Add Product")
        print("2. Delete Product")
        print("3. List Products")
        print("4. Update Price")
        print("5. Update Stock")
        print("6. Report")
        print("7. Exit")

        choice = input("Select an option (1-7): ").strip()

        if choice == "1":
            add_product()
        elif choice == "2":
            delete_product()
        elif choice == "3":
            list_products()
        elif choice == "4":
            update_price()
        elif choice == "5":
            update_stock()
        elif choice == "6":
            report()
        elif choice == "7":
            print("Exiting program...")
            break
        else:
            print("Invalid choice. Try again.")


if __name__ == "__main__":
    main()
